import os
import sys
import numpy as np

def binary_cross_entropy(true, pred, eps=1e-16):
    """
    Compute binary cross entropy between true and pred numpy arrays.
    Args:
        true (np.ndarray): Ground truth binary labels (0 or 1).
        pred (np.ndarray): Predicted probabilities (between 0 and 1).
        eps (float): Small value to avoid log(0).
    Returns:
        float: Mean binary cross entropy.
    """
    pred = np.clip(pred, eps, 1 - eps)
    bce = - (true * np.log(pred) + (1 - true) * np.log(1 - pred))
    return np.mean(bce)


def classification_scoring(INPUT_DIR = None, # directory to where to find the reference and predicted labes
                           OUTPUT_DIR = None # directory where the scores will be saved (scores.txt)
                        ):
    
    print("Entered classification scoring function")
    
    if INPUT_DIR is None:
        INPUT_DIR = sys.argv[1]
    if OUTPUT_DIR is None:
        OUTPUT_DIR = sys.argv[2]
        
    submit_dir = os.path.join(INPUT_DIR, 'res')
    truth_dir = os.path.join(INPUT_DIR, 'ref')
    
    if not os.path.isdir(submit_dir):
        print( "%s doesn't exist", submit_dir)
        
    if os.path.isdir(submit_dir) and os.path.isdir(truth_dir):
        if not os.path.exists(OUTPUT_DIR):
            os.makedirs(OUTPUT_DIR)

    output_filename = os.path.join(OUTPUT_DIR, 'scores.txt')
    output_file = open(output_filename, 'w')

    # Load ground truth
    print('Loading ground truth labels')
    trues = np.load(os.path.join(truth_dir, 'true_class.npy'))
    # Results file
    print('Loading predicted labels')
    preds = np.load(os.path.join(submit_dir, 'preds.npy'))

    print('Calculating binary cross entropy loss')
    loss = binary_cross_entropy(trues, preds)

    print('Saving data')
    output_file.write(f'loss: {loss}\n')