'''
Sample predictive model.
You must supply at least 4 methods:
- fit: trains the model.
- predict: uses the model to perform predictions.
- save: saves the model.
- load: reloads the model.
'''
import numpy as np   # We recommend to use numpy arrays
from os.path import isfile

class model:
    def __init__(self):
        '''
        This constructor is supposed to initialize data members.
        Use triple quotes for function documentation.
        '''
        self.the_number = np.random.rand()
    
    def pred(self, x):
        return x.mean(-1).mean(-1)